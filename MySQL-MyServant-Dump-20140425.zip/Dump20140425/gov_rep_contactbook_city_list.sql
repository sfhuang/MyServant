CREATE DATABASE  IF NOT EXISTS `gov_rep_contactbook` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gov_rep_contactbook`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: www.uisltsc.com.tw    Database: gov_rep_contactbook
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `city_list`
--

DROP TABLE IF EXISTS `city_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city_list` (
  `city_id` int(11) NOT NULL auto_increment,
  `city_type` enum('dis_city','prov_city','county','other') NOT NULL default 'county',
  `city_name` varchar(45) NOT NULL,
  `province_id` int(11) NOT NULL default '1',
  `legislator_election_district_id` int(11) default NULL,
  `city_level_rep_elect_n_dist_id` int(11) default NULL,
  `city_level_rep_elect_pna_dist_id` int(11) default NULL,
  `city_level_rep_elect_mna_dist_id` int(11) default NULL,
  `governor_name` varchar(45) default NULL,
  `mayor_party_id` int(11) default NULL,
  PRIMARY KEY  (`city_id`),
  UNIQUE KEY `city_name_UNIQUE` (`city_name`),
  KEY `city_to_province_idx` (`province_id`),
  KEY `city_to_legislator_election_district_idx` (`legislator_election_district_id`),
  KEY `city_to_citylevel_rep_elect_dist_idx` (`city_level_rep_elect_n_dist_id`),
  KEY `city_to_citylevel_rep_elect_pna_dist_idx` (`city_level_rep_elect_pna_dist_id`),
  KEY `city_to_citylevel_rep_elect_mna_dist_idx` (`city_level_rep_elect_mna_dist_id`),
  CONSTRAINT `city_to_citylevel_rep_elect_mna_dist` FOREIGN KEY (`city_level_rep_elect_mna_dist_id`) REFERENCES `local_representative_election_district_list` (`local_rep_elect_dist_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `city_to_citylevel_rep_elect_n_dist` FOREIGN KEY (`city_level_rep_elect_n_dist_id`) REFERENCES `local_representative_election_district_list` (`local_rep_elect_dist_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `city_to_citylevel_rep_elect_pna_dist` FOREIGN KEY (`city_level_rep_elect_pna_dist_id`) REFERENCES `local_representative_election_district_list` (`local_rep_elect_dist_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `city_to_legislator_election_district` FOREIGN KEY (`legislator_election_district_id`) REFERENCES `legislator_election_district_list` (`legislator_election_district_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `city_to_province` FOREIGN KEY (`province_id`) REFERENCES `province_list` (`province_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city_list`
--

LOCK TABLES `city_list` WRITE;
/*!40000 ALTER TABLE `city_list` DISABLE KEYS */;
INSERT INTO `city_list` VALUES (1,'dis_city','臺北市',1,NULL,NULL,NULL,NULL,'郝龍斌',1),(2,'dis_city','新北市',1,NULL,NULL,NULL,NULL,'朱立倫',1),(3,'dis_city','臺中市',1,NULL,NULL,NULL,NULL,'胡自強',1),(4,'dis_city','臺南市',1,NULL,NULL,NULL,NULL,'賴清德',2),(5,'dis_city','高雄市',1,NULL,NULL,NULL,NULL,'陳菊',2),(6,'prov_city','基隆市',1,9,NULL,NULL,NULL,'張通榮',1),(7,'prov_city','新竹市',1,29,NULL,NULL,NULL,'許明財',1),(8,'prov_city','嘉義市',1,49,NULL,NULL,NULL,'黃敏惠',1),(9,'county','桃園縣',1,NULL,NULL,NULL,NULL,'吳志揚',1),(10,'county','新竹縣',1,30,NULL,NULL,NULL,'邱鏡淳',1),(11,'county','苗栗縣',1,NULL,NULL,NULL,NULL,'劉政鴻',1),(12,'county','彰化縣',1,NULL,NULL,NULL,NULL,'卓伯源',1),(13,'county','南投縣',1,NULL,NULL,NULL,NULL,'李朝卿',1),(14,'county','雲林縣',1,NULL,NULL,NULL,NULL,'蘇治芬',2),(15,'county','嘉義縣',1,NULL,NULL,NULL,NULL,'張花冠',2),(16,'county','屏東縣',1,NULL,NULL,NULL,NULL,'曹啟鴻',2),(17,'county','宜蘭縣',1,22,NULL,NULL,NULL,'林聰賢',2),(18,'county','花蓮縣',1,70,NULL,NULL,NULL,'傅崐萁',0),(19,'county','臺東縣',1,69,NULL,NULL,NULL,'黃健庭',1),(20,'county','澎湖縣',1,71,NULL,NULL,NULL,'王乾發',1),(21,'county','金門縣',2,72,NULL,NULL,NULL,'李沃士',1),(22,'county','連江縣',2,73,NULL,NULL,NULL,'湯綏生',1);
/*!40000 ALTER TABLE `city_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-25 14:26:45
