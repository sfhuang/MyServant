CREATE DATABASE  IF NOT EXISTS `gov_rep_contactbook` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gov_rep_contactbook`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: www.uisltsc.com.tw    Database: gov_rep_contactbook
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `legislator_election_district_list`
--

DROP TABLE IF EXISTS `legislator_election_district_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legislator_election_district_list` (
  `legislator_election_district_id` int(11) NOT NULL auto_increment,
  `legislator_election_district_name` varchar(45) NOT NULL,
  `legislator_election_district_name_abbreviation` varchar(20) NOT NULL,
  `sequence` tinyint(4) NOT NULL default '8',
  PRIMARY KEY  (`legislator_election_district_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legislator_election_district_list`
--

LOCK TABLES `legislator_election_district_list` WRITE;
/*!40000 ALTER TABLE `legislator_election_district_list` DISABLE KEYS */;
INSERT INTO `legislator_election_district_list` VALUES (1,'臺北市第01選區','臺北01',8),(2,'臺北市第02選區','臺北02',8),(3,'臺北市第03選區','臺北03',8),(4,'臺北市第04選區','臺北04',8),(5,'臺北市第05選區','臺北05',8),(6,'臺北市第06選區','臺北06',8),(7,'臺北市第07選區','臺北07',8),(8,'臺北市第08選區','臺北08',8),(9,'基隆市選區','基隆市',8),(10,'新北市第01選區','新北01',8),(11,'新北市第02選區','新北02',8),(12,'新北市第03選區','新北03',8),(13,'新北市第04選區','新北04',8),(14,'新北市第05選區','新北05',8),(15,'新北市第06選區','新北06',8),(16,'新北市第07選區','新北07',8),(17,'新北市第08選區','新北08',8),(18,'新北市第09選區','新北09',8),(19,'新北市第10選區','新北10',8),(20,'新北市第11選區','新北11',8),(21,'新北市第12選區','新北12',8),(22,'宜蘭縣選區','宜蘭縣',8),(23,'桃園縣第01選區','桃園01',8),(24,'桃園縣第02選區','桃園02',8),(25,'桃園縣第03選區','桃園03',8),(26,'桃園縣第04選區','桃園04',8),(27,'桃園縣第05選區','桃園05',8),(28,'桃園縣第06選區','桃園06',8),(29,'新竹市選區','新竹市',8),(30,'新竹縣選區','新竹縣',8),(31,'苗栗縣第01選區','苗縣01',8),(32,'苗栗縣第02選區','苗縣02',8),(33,'臺中市第01選區','臺中01',8),(34,'臺中市第02選區','臺中02',8),(35,'臺中市第03選區','臺中03',8),(36,'臺中市第04選區','臺中04',8),(37,'臺中市第05選區','臺中05',8),(38,'臺中市第06選區','臺中06',8),(39,'臺中市第07選區','臺中07',8),(40,'臺中市第08選區','臺中08',8),(41,'彰化縣第01選區','彰化01',8),(42,'彰化縣第02選區','彰化02',8),(43,'彰化縣第03選區','彰化03',8),(44,'彰化縣第04選區','彰化04',8),(45,'南投縣第01選區','南投01',8),(46,'南投縣第02選區','南投02',8),(47,'雲林縣第01選區','雲林01',8),(48,'雲林縣第02選區','雲林02',8),(49,'嘉義市選區','嘉義市',8),(50,'嘉義縣第01選區','嘉縣01',8),(51,'嘉義縣第02選區','嘉縣02',8),(52,'臺南市第01選區','臺南01',8),(53,'臺南市第02選區','臺南02',8),(54,'臺南市第03選區','臺南03',8),(55,'臺南市第04選區','臺南04',8),(56,'臺南市第05選區','臺南05',8),(57,'高雄市第01選區','高雄01',8),(58,'高雄市第02選區','高雄02',8),(59,'高雄市第03選區','高雄03',8),(60,'高雄市第04選區','高雄04',8),(61,'高雄市第05選區','高雄05',8),(62,'高雄市第06選區','高雄06',8),(63,'高雄市第07選區','高雄07',8),(64,'高雄市第08選區','高雄08',8),(65,'高雄市第09選區','高雄09',8),(66,'屏東縣第01選區','屏東01',8),(67,'屏東縣第02選區','屏東02',8),(68,'屏東縣第03選區','屏東03',8),(69,'臺東縣選區','臺東縣',8),(70,'花蓮縣選區','花蓮縣',8),(71,'澎湖縣選區','澎湖縣',8),(72,'金門縣選區','金門縣',8),(73,'連江縣選區','連江縣',8),(6666,'平地原住民','平地原',8),(7777,'山地原住民','山地原',8),(8888,'僑居國外國民','僑外居',8),(9999,'全國不分區','不分區',8);
/*!40000 ALTER TABLE `legislator_election_district_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-25 14:26:53
