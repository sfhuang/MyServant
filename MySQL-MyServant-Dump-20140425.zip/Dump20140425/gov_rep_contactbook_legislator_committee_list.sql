CREATE DATABASE  IF NOT EXISTS `gov_rep_contactbook` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gov_rep_contactbook`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: www.uisltsc.com.tw    Database: gov_rep_contactbook
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `legislator_committee_list`
--

DROP TABLE IF EXISTS `legislator_committee_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legislator_committee_list` (
  `legislator_committee_id` int(11) NOT NULL,
  `legislator_committee_name` varchar(45) NOT NULL,
  `legislator_committee_name_abbreviation` varchar(45) NOT NULL,
  PRIMARY KEY  (`legislator_committee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legislator_committee_list`
--

LOCK TABLES `legislator_committee_list` WRITE;
/*!40000 ALTER TABLE `legislator_committee_list` DISABLE KEYS */;
INSERT INTO `legislator_committee_list` VALUES (0,'內政委員會','內政委員會'),(1,'教育及文化委員會','教育及文化'),(2,'外交及國防委員會','外交及國防'),(3,'交通委員會','交通委員會'),(4,'經濟委員會','經濟委員會'),(5,'司法及法制委員會','司法及法制'),(6,'財政委員會','財政委員會'),(7,'社會福利及衛生環境委員會','社福及衛環'),(8,'程序委員會','程序委員會'),(9,'紀律委員會','紀律委員會'),(10,'修憲委員會','修憲委員會'),(11,'經費稽核委員會','經費稽核');
/*!40000 ALTER TABLE `legislator_committee_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-25 14:26:45
