CREATE DATABASE  IF NOT EXISTS `gov_rep_contactbook` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gov_rep_contactbook`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: www.uisltsc.com.tw    Database: gov_rep_contactbook
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `legislator_committee_pair`
--

DROP TABLE IF EXISTS `legislator_committee_pair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legislator_committee_pair` (
  `legislator_committee_id` int(11) NOT NULL,
  `legislator_id` int(11) NOT NULL,
  `convener` tinyint(1) NOT NULL default '0',
  `sequence` tinyint(4) NOT NULL default '8',
  `semester` tinyint(1) NOT NULL default '4',
  PRIMARY KEY  (`legislator_committee_id`,`legislator_id`),
  KEY `legist_comm_p_to_legislator_idx` (`legislator_id`),
  KEY `legist_comm_p_to_commission_idx` (`legislator_committee_id`),
  CONSTRAINT `legist_commit_to_committee` FOREIGN KEY (`legislator_committee_id`) REFERENCES `legislator_committee_list` (`legislator_committee_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `legist_commit_to_legislator` FOREIGN KEY (`legislator_id`) REFERENCES `legislator_list` (`legislator_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legislator_committee_pair`
--

LOCK TABLES `legislator_committee_pair` WRITE;
/*!40000 ALTER TABLE `legislator_committee_pair` DISABLE KEYS */;
INSERT INTO `legislator_committee_pair` VALUES (0,10,0,8,4),(0,14,0,8,4),(0,20,0,8,4),(0,35,0,8,4),(0,38,0,8,4),(0,40,1,8,4),(0,42,0,8,4),(0,45,0,8,4),(0,50,0,8,4),(0,52,1,8,4),(0,56,0,8,4),(0,57,0,8,4),(0,64,0,8,4),(0,72,0,8,4),(1,2,0,8,4),(1,12,0,8,4),(1,17,0,8,4),(1,21,0,8,4),(1,26,0,8,4),(1,36,1,8,4),(1,55,0,8,4),(1,59,0,8,4),(1,62,1,8,4),(1,68,0,8,4),(1,73,0,8,4),(1,96,0,8,4),(1,97,0,8,4),(1,99,0,8,4),(2,6,0,8,4),(2,8,0,8,4),(2,29,0,8,4),(2,37,1,8,4),(2,48,0,8,4),(2,60,0,8,4),(2,66,0,8,4),(2,67,0,8,4),(2,69,1,8,4),(2,77,0,8,4),(2,83,0,8,4),(2,94,0,8,4),(2,102,0,8,4),(3,4,0,8,4),(3,19,0,8,4),(3,25,0,8,4),(3,28,0,8,4),(3,30,0,8,4),(3,61,1,8,4),(3,63,0,8,4),(3,80,0,8,4),(3,81,0,8,4),(3,86,1,8,4),(3,89,0,8,4),(3,93,0,8,4),(3,101,0,8,4),(3,108,0,8,4),(3,110,0,8,4),(4,1,0,8,4),(4,23,0,8,4),(4,27,0,8,4),(4,32,0,8,4),(4,46,0,8,4),(4,49,0,8,4),(4,51,0,8,4),(4,53,0,8,4),(4,58,1,8,4),(4,74,0,8,4),(4,75,0,8,4),(4,79,1,8,4),(4,85,0,8,4),(4,106,0,8,4),(4,112,0,8,4),(5,3,0,8,4),(5,7,0,8,4),(5,15,1,8,4),(5,18,1,8,4),(5,34,0,8,4),(5,39,0,8,4),(5,41,0,8,4),(5,84,0,8,4),(5,90,0,8,4),(5,91,0,8,4),(5,103,0,8,4),(5,105,0,8,4),(5,107,0,8,4),(6,16,0,8,4),(6,22,0,8,4),(6,24,0,8,4),(6,33,0,8,4),(6,43,0,8,4),(6,47,0,8,4),(6,54,0,8,4),(6,70,0,8,4),(6,71,0,8,4),(6,92,0,8,4),(6,100,1,8,4),(6,104,1,8,4),(6,109,0,8,4),(7,5,0,8,4),(7,9,0,8,4),(7,11,1,8,4),(7,13,0,8,4),(7,31,0,8,4),(7,44,0,8,4),(7,65,0,8,4),(7,76,0,8,4),(7,78,0,8,4),(7,82,0,8,4),(7,87,1,8,4),(7,88,0,8,4),(7,95,0,8,4),(7,98,0,8,4),(7,111,0,8,4),(8,3,0,8,4),(8,5,0,8,4),(8,9,0,8,4),(8,14,1,8,4),(8,15,0,8,4),(8,22,0,8,4),(8,24,0,8,4),(8,33,0,8,4),(8,34,0,8,4),(8,35,0,8,4),(8,44,0,8,4),(8,53,0,8,4),(8,56,1,8,4),(8,69,0,8,4),(8,83,0,8,4),(8,84,0,8,4),(8,94,0,8,4),(8,103,0,8,4),(8,104,0,8,4),(9,11,1,8,4),(9,15,0,8,4),(9,18,1,8,4),(9,36,1,8,4),(9,37,0,8,4),(9,40,0,8,4),(9,52,1,8,4),(9,58,1,8,4),(9,61,1,8,4),(9,62,0,8,4),(9,69,1,8,4),(9,79,0,8,4),(9,86,0,8,4),(9,87,0,8,4),(9,100,0,8,4),(9,104,1,8,4),(11,26,0,8,4),(11,30,1,8,4),(11,64,0,8,4),(11,75,0,8,4),(11,81,1,8,4),(11,82,0,8,4),(11,85,0,8,4),(11,91,0,8,4),(11,98,1,8,4);
/*!40000 ALTER TABLE `legislator_committee_pair` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-25 14:26:54
