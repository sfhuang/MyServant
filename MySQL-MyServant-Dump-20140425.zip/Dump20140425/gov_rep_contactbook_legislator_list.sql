CREATE DATABASE  IF NOT EXISTS `gov_rep_contactbook` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gov_rep_contactbook`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: www.uisltsc.com.tw    Database: gov_rep_contactbook
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `legislator_list`
--

DROP TABLE IF EXISTS `legislator_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legislator_list` (
  `legislator_id` int(11) NOT NULL auto_increment,
  `legislator_name` varchar(45) NOT NULL,
  `party_id` smallint(6) NOT NULL default '0',
  `legislator_election_district_id` int(11) default NULL,
  `legislator_type_id` int(11) NOT NULL,
  `sequence` tinyint(4) NOT NULL,
  `active` tinyint(1) NOT NULL default '1',
  `special_note` text,
  `position_id` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`legislator_id`),
  KEY `legislator_to_election_district_idx` (`legislator_election_district_id`),
  KEY `legislator_to_type_idx` (`legislator_type_id`),
  KEY `legislator_party_idx` (`party_id`),
  KEY `legislator_to_position_idx` (`position_id`),
  CONSTRAINT `legislator_to_election_district` FOREIGN KEY (`legislator_election_district_id`) REFERENCES `legislator_election_district_list` (`legislator_election_district_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `legislator_to_party` FOREIGN KEY (`party_id`) REFERENCES `party_list` (`party_id`) ON UPDATE CASCADE,
  CONSTRAINT `legislator_to_position` FOREIGN KEY (`position_id`) REFERENCES `position_list` (`position_id`) ON UPDATE CASCADE,
  CONSTRAINT `legislator_to_type` FOREIGN KEY (`legislator_type_id`) REFERENCES `legislator_type_list` (`legislator_type_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legislator_list`
--

LOCK TABLES `legislator_list` WRITE;
/*!40000 ALTER TABLE `legislator_list` DISABLE KEYS */;
INSERT INTO `legislator_list` VALUES (1,'丁守中',1,1,1,8,1,NULL,0),(2,'孔文吉',1,7777,3,8,1,NULL,0),(3,'尤美女',2,9999,0,8,1,NULL,0),(4,'王廷升',1,70,1,8,1,NULL,0),(5,'王育敏',1,9999,0,8,1,NULL,0),(6,'王金平',1,9999,0,8,1,NULL,0),(7,'王惠美',1,41,1,8,1,NULL,0),(8,'王進士',1,67,1,8,1,NULL,0),(9,'田秋堇',2,9999,0,8,1,NULL,0),(10,'江啟臣',1,40,1,8,1,NULL,0),(11,'江惠貞',1,16,1,8,1,NULL,0),(12,'何欣純',2,39,1,8,1,NULL,0),(13,'吳育仁',1,9999,0,8,1,NULL,0),(14,'吳育昇',1,10,1,8,1,NULL,0),(15,'吳宜臻',2,9999,0,8,1,NULL,0),(16,'吳秉叡',2,9999,0,8,1,NULL,0),(17,'呂玉玲',1,27,1,8,1,NULL,0),(18,'呂學樟',1,29,1,8,1,NULL,0),(19,'李昆澤',2,62,1,8,1,NULL,0),(20,'李俊俋',2,49,1,8,1,NULL,0),(21,'李桐豪',4,9999,0,8,1,NULL,0),(22,'李貴敏',1,9999,0,8,1,NULL,0),(23,'李慶華',1,21,1,8,1,NULL,0),(24,'李應元',2,9999,0,8,1,NULL,0),(25,'李鴻鈞',1,13,1,8,1,NULL,0),(26,'林佳龍',2,38,1,8,1,NULL,0),(27,'林岱樺',2,60,1,8,1,NULL,0),(28,'林明溱',1,46,1,8,1,NULL,0),(29,'林郁方',1,5,1,8,1,NULL,0),(30,'林國正',1,65,1,8,1,NULL,0),(31,'林淑芬',2,11,1,8,1,NULL,0),(32,'林滄敏',1,42,1,8,1,NULL,0),(33,'林德福',1,18,1,8,1,NULL,0),(34,'林鴻池',1,15,1,8,1,NULL,0),(35,'邱文彥',1,9999,0,8,1,NULL,0),(36,'邱志偉',2,58,1,8,1,NULL,0),(37,'邱議瑩',2,57,1,8,1,NULL,0),(38,'姚文智',2,2,1,8,1,NULL,0),(39,'柯建銘',2,9999,0,8,1,NULL,0),(40,'段宜康',2,9999,0,8,1,NULL,0),(41,'洪秀柱',1,9999,0,8,1,NULL,0),(42,'紀國棟',1,9999,0,8,1,NULL,0),(43,'孫大千',1,28,1,8,1,NULL,0),(44,'徐少萍',1,9999,0,8,1,NULL,0),(45,'徐欣瑩',1,30,1,8,1,NULL,0),(46,'徐耀昌',1,32,1,8,1,NULL,0),(47,'翁重鈞',1,50,1,8,1,NULL,0),(48,'馬文君',1,45,1,8,1,NULL,0),(49,'高志鵬',2,12,1,8,1,NULL,0),(50,'高金素梅',5,7777,3,8,1,NULL,0),(51,'張嘉郡',1,47,1,8,1,NULL,0),(52,'張慶忠',1,17,1,8,1,NULL,0),(53,'周倪安',3,9999,0,8,1,NULL,0),(54,'許添財',2,55,1,8,1,NULL,0),(55,'許智傑',2,64,1,8,1,NULL,0),(56,'陳其邁',2,9999,0,8,1,NULL,0),(57,'陳怡潔',4,9999,0,8,1,NULL,0),(58,'陳明文',2,51,1,8,1,NULL,0),(59,'陳亭妃',2,54,1,8,1,NULL,0),(60,'陳唐山',2,56,1,8,1,NULL,0),(61,'陳根德',1,23,1,8,1,NULL,0),(62,'陳淑慧',1,9999,0,8,1,NULL,0),(63,'陳雪生',0,73,1,8,1,NULL,0),(64,'陳超明',1,31,1,8,1,NULL,0),(65,'陳節如',2,9999,0,8,1,NULL,0),(66,'陳碧涵',1,9999,0,8,1,NULL,0),(67,'陳歐珀',2,22,1,8,1,NULL,0),(68,'陳學聖',1,25,1,8,1,NULL,0),(69,'陳鎮湘',1,9999,0,8,1,NULL,0),(70,'曾巨威',1,9999,0,8,1,NULL,0),(71,'費鴻泰',1,7,1,8,1,NULL,0),(72,'賴振昌',3,9999,0,8,1,NULL,0),(73,'黃志雄',1,14,1,8,1,NULL,0),(74,'黃昭順',1,59,1,8,1,NULL,0),(75,'黃偉哲',2,53,1,8,1,NULL,0),(76,'楊玉欣',1,9999,0,8,1,NULL,0),(77,'楊應雄',1,72,1,8,1,NULL,0),(78,'楊曜',2,71,1,8,1,NULL,0),(79,'楊瓊瓔',1,35,1,8,1,NULL,0),(80,'楊麗環',1,26,1,8,1,NULL,0),(81,'葉宜津',2,52,1,8,1,NULL,0),(82,'葉津鈴',3,9999,0,8,1,NULL,0),(83,'詹凱臣',1,8888,4,8,1,NULL,0),(84,'廖正井',1,24,1,8,1,NULL,0),(85,'廖國棟',1,6666,2,8,1,NULL,0),(86,'管碧玲',2,61,1,8,1,NULL,0),(87,'趙天麟',2,63,1,8,1,NULL,0),(88,'劉建國',2,48,1,8,1,NULL,0),(89,'劉櫂豪',2,69,1,8,1,NULL,0),(90,'潘孟安',2,68,1,8,1,NULL,0),(91,'潘維剛',1,9999,0,8,1,NULL,0),(92,'蔡正元',1,4,1,8,1,NULL,0),(93,'蔡其昌',2,33,1,8,1,NULL,0),(94,'蔡煌瑯',2,9999,0,8,1,NULL,0),(95,'蔡錦隆',1,36,1,8,1,NULL,0),(96,'蔣乃辛',1,6,1,8,1,NULL,0),(97,'鄭天財',1,6666,2,8,1,NULL,0),(98,'鄭汝芬',1,43,1,8,1,NULL,0),(99,'鄭麗君',2,9999,0,8,1,NULL,0),(100,'盧秀燕',1,37,1,8,1,NULL,0),(101,'盧嘉辰',1,19,1,8,1,NULL,0),(102,'蕭美琴',2,9999,0,8,1,NULL,0),(103,'賴士葆',1,8,1,8,1,NULL,0),(104,'薛凌',2,9999,0,8,1,NULL,0),(105,'謝國樑',1,9,1,8,1,NULL,0),(106,'簡東明',1,7777,3,8,1,NULL,0),(107,'顏寬恒',1,34,1,8,1,NULL,0),(108,'魏明谷',2,44,1,8,1,NULL,0),(109,'羅明才',1,20,1,8,1,NULL,0),(110,'羅淑蕾',1,3,1,8,1,NULL,0),(111,'蘇清泉',1,9999,0,8,1,NULL,0),(112,'蘇震清',2,66,1,8,1,NULL,0);
/*!40000 ALTER TABLE `legislator_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-25 14:26:46
